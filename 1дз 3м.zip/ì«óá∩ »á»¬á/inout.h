﻿#ifndef INOUT_H
#define INOUT_H

#include <vector>
void print(const std::vector<int>& vec);
void read(std::vector<int>& vec);

#endif // INOUT_H